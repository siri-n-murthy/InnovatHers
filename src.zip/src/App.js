import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Lessons from "./pages/Lessons"; // ✅ Import Lessons
import QuizGames from "./pages/QuizGames";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/lessons" element={<Lessons />} /> {/* ✅ lowercase path */}
        <Route path="/quiz-games" element={<QuizGames />} />
      </Routes>
    </Router>
  );
}

export default App;
