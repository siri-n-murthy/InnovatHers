import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./Dashboard.css";

const translations = {
  en: {
    welcome: "Welcome",
    dashboardText: "Here’s your learning dashboard.",
    logout: "Log out",
    myLessons: "My Lessons",
    myLessonsDesc: "Access all your lessons and study materials offline.",
    quizGames: "Quiz Games",
    quizGamesDesc: "Challenge yourself and earn tokens with fun quizzes.",
    practiceWithVoice: "Practice with Voice",
    practiceWithVoiceDesc:
      "Use speech tools to improve pronunciation and learn hands-free.",
    tokensRewards: "Tokens & Rewards",
    tokensRewardsDesc: "Track your progress and redeem rewards.",
    languageLabel: "Language",
    learner: "Learner",
  },
  kn: {
    welcome: "ಸ್ವಾಗತ",
    dashboardText: "ಇದು ನಿಮ್ಮ ಅಧ್ಯಯನ ಡ್ಯಾಶ್‌ಬೋರ್ಡ್.",
    logout: "ಲಾಗ್ ಔಟ್",
    myLessons: "ನನ್ನ ಪಾಠಗಳು",
    myLessonsDesc: "ನಿಮ್ಮ ಎಲ್ಲಾ ಪಾಠಗಳು ಮತ್ತು ಅಧ್ಯಯನ ಸಾಮಗ್ರಿಗಳನ್ನು ಆಫ್‌ಲೈನ್‌ನಲ್ಲಿ ಪ್ರವೇಶಿಸಿ.",
    quizGames: "ಕ್ವಿಜ್ ಗೇಮ್ಸ್",
    quizGamesDesc: "ತೊರೆದುಕೊಂಡು ಮೋಜಿನ ಪ್ರಶ್ನೋತ್ತರಗಳೊಂದಿಗೆ ಟೋಕನ್ ಗಳಿಸಿ.",
    practiceWithVoice: "ಸ್ವರ ಅಭ್ಯಾಸ",
    practiceWithVoiceDesc:
      "ಉಚ್ಛಾರಣೆಯನ್ನು ಸುಧಾರಿಸಲು ಧ್ವನಿ ಸಾಧನಗಳನ್ನು ಬಳಸಿ ಮತ್ತು ಕೈಮುಕ್ತವಾಗಿ ಕಲಿಯಿರಿ.",
    tokensRewards: "ಟೋಕನ್ಗಳು ಮತ್ತು ಬಹುಮಾನಗಳು",
    tokensRewardsDesc: "ನಿಮ್ಮ ಪ್ರಗತಿಯನ್ನು ಟ್ರ್ಯಾಕ್ ಮಾಡಿ ಮತ್ತು ಬಹುಮಾನಗಳನ್ನು ಪಡೆದುಕೊಳ್ಳಿ.",
    languageLabel: "ಭಾಷೆ",
    learner: "ಕಲಿಯುವವರು",
  },
  hi: {
    welcome: "स्वागत है",
    dashboardText: "यह आपका लर्निंग डैशबोर्ड है।",
    logout: "लॉग आउट",
    myLessons: "मेरे पाठ",
    myLessonsDesc: "अपने सभी पाठ और अध्ययन सामग्री ऑफलाइन एक्सेस करें।",
    quizGames: "क्विज़ गेम्स",
    quizGamesDesc: "मज़ेदार क्विज़ के साथ खुद को चुनौती दें और टोकन कमाएं।",
    practiceWithVoice: "वॉइस प्रैक्टिस",
    practiceWithVoiceDesc:
      "उच्चारण सुधारने के लिए स्पीच टूल्स का उपयोग करें और हैंड्स-फ्री सीखें।",
    tokensRewards: "टोकन और पुरस्कार",
    tokensRewardsDesc: "अपनी प्रगति ट्रैक करें और पुरस्कार भुनाएं।",
    languageLabel: "भाषा",
    learner: "शिक्षार्थी",
  },
};

function Dashboard() {
  const [language, setLanguage] = useState("en");
  const name = localStorage.getItem("childName") || translations[language].learner;
  const navigate = useNavigate();

  const logout = () => {
    console.log("Logging out...");
    localStorage.removeItem("childName");
    navigate("/");
  };

  const t = translations[language];

  return (
    <div className="dashboard-container">
      <aside className="sidebar">
        <h2 className="sidebar-brand">EduBridge+</h2>
        <nav>
          <ul>
            <li>
              📘 <Link to="/Lessons" className="sidebar-link">{t.myLessons}</Link>
            </li>
            <li>
              🧩 <Link to="/quiz-games" className="sidebar-link">{t.quizGames}</Link>
            </li>
            <li>🎤 {t.practiceWithVoice}</li>
            <li>🏆 {t.tokensRewards}</li>
          </ul>
        </nav>
        <button className="logout-btn" onClick={logout}>
          {t.logout}
        </button>
      </aside>

      <main className="main-content">
        <header
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <div>
            <h1>
              {t.welcome}, {name}! 👋
            </h1>
            <p>{t.dashboardText}</p>
          </div>

          {/* Language Selector */}
          <div>
            <label
              htmlFor="language-select"
              style={{ marginRight: "8px", fontWeight: "600" }}
            >
              {t.languageLabel}:
            </label>
            <select
              id="language-select"
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              style={{ padding: "4px" }}
            >
              <option value="en">English</option>
              <option value="kn">ಕನ್ನಡ</option>
              <option value="hi">हिन्दी</option>
            </select>
          </div>
        </header>

        <section className="cards">
          <div className="card">
            <h3>📘 {t.myLessons}</h3>
            <p>{t.myLessonsDesc}</p>
          </div>
          <div className="card">
            <h3>🧩 {t.quizGames}</h3>
            <p>{t.quizGamesDesc}</p>
          </div>
          <div className="card">
            <h3>🎤 {t.practiceWithVoice}</h3>
            <p>{t.practiceWithVoiceDesc}</p>
          </div>
          <div className="card">
            <h3>🏆 {t.tokensRewards}</h3>
            <p>{t.tokensRewardsDesc}</p>
          </div>
        </section>
      </main>
    </div>
  );
}

export default Dashboard;