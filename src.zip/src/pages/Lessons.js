import React from "react";
import { useNavigate } from "react-router-dom";
import "./Lessons.css";


function Lessons() {
  const navigate = useNavigate();

  const lessonsData = [
    {
      id: 1,
      title: "🎥 Educational Videos",
      description: "Watch videos on literacy, farming, and more.",
      link: "https://www.youtube.com/playlist?list=PLeducational",
      buttonText: "Watch Videos",
    },
    {
      id: 2,
      title: "📚 Reading Books",
      description: "Download or read offline study materials and storybooks.",
      link: "/reading-materials",
      buttonText: "Explore Books",
    },
    {
      id: 3,
      title: "🌍 General Knowledge",
      description: "Boost your knowledge with quizzes and interesting facts.",
      link: "/general-knowledge",
      buttonText: "Learn More",
    },
  ];

  return (
    <div className="lessons-container">
      <header>
        <h1>Learning Lessons</h1>
        <p>Choose a section to start learning.</p>
        <button onClick={() => navigate(-1)} className="back-btn">
          ← Back to Dashboard
        </button>
      </header>

      <section className="lessons-cards">
        {lessonsData.map(({ id, title, description, link, buttonText }) => (
          <div key={id} className="lesson-card">
            <h2>{title}</h2>
            <p>{description}</p>
            {link.startsWith("http") ? (
              <a href={link} target="_blank" rel="noopener noreferrer" className="btn">
                {buttonText}
              </a>
            ) : (
              <button className="btn" onClick={() => navigate(link)}>
                {buttonText}
              </button>
            )}
          </div>
        ))}
      </section>
    </div>
  );
}

export default Lessons;
