import React, { useState } from "react";
import "./QuizGames.css";


const riddleQuestions = [
  { question: "There is a tree that gives clothes instead of fruits. What is it?", answer: "cotton" },
  { question: "What is used for both drinking and bathing?", answer: "water" },
  { question: "I am a house with no people, but I can be found everywhere. What am I?", answer: "envelope" },
  { question: "I am never hungry, but I eat everything. What am I?", answer: "fire" },
  { question: "I am not a plant or a tree, but I come every day. What am I?", answer: "newspaper" },
];

const objectQuestions = [
  { clue: "I’m small and white, made from chalk dust, and used to write on blackboards.", answer: "chalk" },
  { clue: "I’m made of wood, I’m long and thin, and I write until I’m sharpened again.", answer: "pencil" },
  { clue: "I’m round and red, juicy and sweet. I keep doctors away when you eat me.", answer: "apple" },
  { clue: "I’m small and green, found in a pod, used in many vegetable dishes.", answer: "pea" },
  { clue: "I’m long and yellow, sweet to eat. Monkeys love me as a treat.", answer: "banana" },
];

export default function QuizGames() {
  const [gameType, setGameType] = useState("riddle"); // 'riddle' or 'object'
  const [step, setStep] = useState(0);
  const [score, setScore] = useState(0);
  const [input, setInput] = useState("");
  const [showResult, setShowResult] = useState(false);

  const current = gameType === "riddle" ? riddleQuestions[step] : objectQuestions[step];

  const handleSubmit = () => {
    if (input.trim().toLowerCase() === current.answer) {
      setScore(score + 1);
    }
    setInput("");
    if (step + 1 < (gameType === "riddle" ? riddleQuestions : objectQuestions).length) {
      setStep(step + 1);
    } else {
      setShowResult(true);
    }
  };

  const resetGame = () => {
    setStep(0);
    setScore(0);
    setInput("");
    setShowResult(false);
  };

  return (
    <div className="quiz-container" style={{ padding: 20 }}>
      <h1>🧩 Quiz Games</h1>

      <div style={{ marginBottom: 20 }}>
        <button onClick={() => { setGameType("riddle"); resetGame(); }}>
          Riddle Time
        </button>
        <button onClick={() => { setGameType("object"); resetGame(); }}>
          Find the Object
        </button>
      </div>

      {!showResult ? (
        <div>
          <h3>
            {gameType === "riddle" ? "Riddle" : "Clue"} {step + 1} of 5
          </h3>
          <p>{gameType === "riddle" ? current.question : current.clue}</p>

          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Your answer"
          />
          <button onClick={handleSubmit}>Submit</button>
        </div>
      ) : (
        <div>
          <h1>🧩 Fun Quiz Time!</h1>
...
<h2>🎉 Hooray! Game Over!</h2>
<p>✨ Your final score is: {score}/5</p>

          <button onClick={resetGame}>Play Again</button>
        </div>
      )}
    </div>
  );
}
