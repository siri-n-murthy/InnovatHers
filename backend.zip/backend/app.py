from flask import Flask, request, jsonify
from flask_mysqldb import MySQL
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# MySQL Configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'edubridge'

mysql = MySQL(app)

@app.route('/api/register', methods=['POST'])
def register():
    data = request.get_json()
    name = data.get('name')
    if not name:
        return jsonify({'error': 'Name is required'}), 400

    cursor = mysql.connection.cursor()
    cursor.execute("INSERT INTO users (name) VALUES (%s)", (name,))
    mysql.connection.commit()
    user_id = cursor.lastrowid
    cursor.close()

    return jsonify({'message': f'User {name} registered successfully', 'user_id': user_id}), 201

@app.route('/api/save-score', methods=['POST'])
def save_score():
    data = request.get_json()
    name = data.get('name')
    score = data.get('score')
    game = data.get('game')

    if not name or score is None or not game:
        return jsonify({'error': 'Name, score, and game are required'}), 400

    cursor = mysql.connection.cursor()
    cursor.execute("SELECT id FROM users WHERE name = %s", (name,))
    user = cursor.fetchone()
    if not user:
        return jsonify({'error': 'User not found'}), 404
    user_id = user[0]

    cursor.execute(
        "INSERT INTO scores (user_id, score, game) VALUES (%s, %s, %s)",
        (user_id, score, game)
    )
    mysql.connection.commit()
    cursor.close()

    return jsonify({'message': 'Score saved successfully'}), 201

@app.route('/api/save-progress', methods=['POST'])
def save_progress():
    data = request.get_json()
    name = data.get('name')
    phrase = data.get('phrase')
    language = data.get('language')

    if not name or not phrase or not language:
        return jsonify({'error': 'Name, phrase, and language are required'}), 400

    cursor = mysql.connection.cursor()
    cursor.execute("SELECT id FROM users WHERE name = %s", (name,))
    user = cursor.fetchone()
    if not user:
        return jsonify({'error': 'User not found'}), 404
    user_id = user[0]

    cursor.execute(
        "INSERT INTO progress (user_id, phrase, language) VALUES (%s, %s, %s)",
        (user_id, phrase, language)
    )
    mysql.connection.commit()
    cursor.close()

    return jsonify({'message': 'Progress saved successfully'}), 201

if __name__ == '__main__':
    app.run(debug=True)